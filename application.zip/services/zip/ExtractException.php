<?php

namespace app\services\zip;

defined('BASEPATH') or exit('No direct script access allowed');

class ExtractException extends \Exception
{
}
